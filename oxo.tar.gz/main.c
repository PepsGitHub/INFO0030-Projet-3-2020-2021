/**
 * controller.c
 * 
 * Ce fichier est le point d'entrée du programme
 * 
 * @author: Dumoulin Peissone S193957
 * @date: 30/03/21
 * @projet: INFO0030 Projet 3
 */

#include <stdio.h>

#include "controller.h"
#include "vue.h"
#include "model.h"

int main(void){















   return 0;
}